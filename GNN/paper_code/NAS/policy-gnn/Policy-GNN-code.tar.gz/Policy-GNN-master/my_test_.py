import numpy as np
a = np.array([0.1, 0.2, 0.3, 0.4, 0.5])
a1 = np.array([0.1, 0.2, 0.3, 0.4, 0.5])
b = np.array([1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 3])
#print(a[b])a
for i in b:
    #print(b)
    a[b] += 1
    a1[i] += 1
print(a)
print(a1)

# a[b] += 1
# print(a)
# print(a[b])


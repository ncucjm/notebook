# Policy-GNN
This is the implementation of Policy-GNN.

## Installation requirements
python3.5.2 <br />
numpy==1.16.4  <br />
torch-cluster==1.4.5  <br />
torch-scatter==1.4.0  <br />
torch-sparse==0.4.3  <br />
torch-geometric==1.3.2  <br />
torch==1.4.0

## Example
python train_cora.py <br />
python train_citeseer.py
